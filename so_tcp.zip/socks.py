import socket
from multiprocessing import Process
import urllib.request
def gethostip(host):
		return socket.gethostbyname(host)

class tcp:
	def __init__(self):
		self.sock = socket.socket()

	def connect(self,ip,port):
		self.sock.connect((ip, port))

	def send(self, data):
		try:
			th1 = Process(target=self.sock.send, args=(data.encode('utf-8'),))
			th1.start()
			th1.join()
		except:
			return False
		else:
			return True

	def close(self):
		self.sock.close()

class udp:
	def __init__(self, ip, port):
		self.ip = ip
		self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

	def send(self, data):
		try:
			th = Process(target=self.sock.sendto, args=(data.encode('utf-8'), (ip, port)))
			th.start()
			th.join()
		except:
			return False
		else:
			return True

	def close(self):
		self.sock.close()
class url:
	def __init__(self, typee):
		self.type = typee
	def open(urls, headers={"User-Agent":"socks/5.0 HTTP Client"}):
		req = urllib.request.Request(urls, headers=headers)